package problem_statement12;

import java.util.HashSet;

public class ABCD {
	public static void main(String[] args) {
		int[] a= {10,21,10,22,32,11,25,32,64,88,112};
		int temp=-1;
		HashSet<Integer>hs=new HashSet<>();
		for(int i=a.length-1; i>=0;i--)
		{
			if(hs.contains(a[i])) {
				temp=i;
			}
			else
			{
				hs.add(a[i]);
			}
		}
		if(temp!=-1) {
			System.out.println("first repeated element is "+a[temp]);
		}
		else {
			System.out.println("first repeated element not found");
		}
	}
}
